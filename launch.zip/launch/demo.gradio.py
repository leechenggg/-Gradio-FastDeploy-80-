
# 导入包
import gradio as gr
import cv2
import fastdeploy 
import fastdeploy.vision as vision

# 准备model
model = vision.detection.PPYOLOE("/home/aistudio/launch/output_inference/model.pdmodel",
"/home/aistudio/launch/output_inference/model.pdiparams", 
"/home/aistudio/launch/output_inference/infer_cfg.yml" )

# 图生图，输入为“image”，输出为“image”
def infer(image):
    result = model.predict(image)
    vis_im = vision.vis_detection(image, result,score_threshold=0.4)
    return vis_im

demo = gr.Interface(fn=infer, title="COCO数据集80类物体检测", inputs=gr.Image(), outputs="image",examples=["./mm.jpg"], cache_examples=True, allow_flagging='never')
demo.launch()